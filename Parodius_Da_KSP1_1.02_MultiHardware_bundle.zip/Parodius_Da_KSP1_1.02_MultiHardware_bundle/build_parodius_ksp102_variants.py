#!/usr/bin/env python3
"""Build a KSP 1.02 Parodius DA package with SCC, SCC+ and dual-SCC variants.

The SCC+ and dual-SCC engines share one HSC1 music-data resource.  The normal
SCC fallback uses the corrected HSC0 conversion.  All pages use RMP1 resource
maps, and HVAR selects dual SCC, SCC+, or normal SCC in descending quality.

This script expects these files beside it unless paths are overridden:
  Parodius_Da_KSP1_1.0(1).ksp
  Parodius_Da_Normal_SCC_KSP1_1.0_fixed.ksp
  ksp_sccplus_to_scc_fixed.py
"""
from __future__ import annotations

import argparse
import binascii
import hashlib
import importlib.util
import json
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

NULL16 = 0xFFFF
NULL32 = 0xFFFFFFFF
PAGE_LOAD = 0x4000
PAGE_SIZE = 0x4000
TRACK = 0x4800
TRACK_OFFSET = TRACK - PAGE_LOAD
WAVE = TRACK + 16
PTR = 0x4700
WAIT = 0x4702
ENDED = 0x4703
FM = 0x4704
VM = 0x4705
WM = 0x4706
LOOPPTR = 0x4707
PAGE_GATEWAY = 0xD8A0
DUAL_SELECT_A = 0xD900
DUAL_SELECT_B = 0xD904
DUAL_RESTORE = 0xD908

KSP_ENGINE_DYNAMIC_PAGES = 1
KSP_HARDWARE_PSG = 1 << 0
KSP_HARDWARE_SCC = 1 << 1
KSP_HARDWARE_SCCPLUS = 1 << 2
KSP_HARDWARE_DUAL_SCC = 1 << 3
KSP_PAGE_RESOURCE_MAP = 3
KSP_COMPRESSION_NONE = 0
KSP_COMPRESSION_ZX0 = 1
KSP_COMPRESSION_ZX0_BLOCKS = 2
KSP_RESOURCE_REQUIRED = 1 << 0
KSP_RESOURCE_STREAMABLE = 1 << 1
KSP_RESOURCE_PAGE_SOURCE = 1 << 2
KSP_TRACK_HIDDEN = 1 << 0

SCC_ENABLE = 0x9000
SCC_WAVE = 0x9800
SCC_FREQ = 0x9880
SCC_VOL = 0x988A
SCC_KEY = 0x988F
SCCP_MODE = 0xBFFE
SCCP_ENABLE = 0xB000
SCCP_WAVE = 0xB800
SCCP_FREQ = 0xB8A0
SCCP_VOL = 0xB8AA
SCCP_KEY = 0xB8AF


def crc32(data: bytes | bytearray) -> int:
    return binascii.crc32(data) & 0xFFFFFFFF


def sha256(data: bytes | bytearray) -> str:
    return hashlib.sha256(data).hexdigest()


def load_converter(path: Path):
    spec = importlib.util.spec_from_file_location("ksp_scc_converter", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class Assembler:
    ORIGIN = 0x4000

    def __init__(self) -> None:
        self.data = bytearray()
        self.labels: Dict[str, int] = {}
        self.fixups: List[Tuple[str, int, str]] = []

    @property
    def pc(self) -> int:
        return self.ORIGIN + len(self.data)

    def label(self, name: str) -> None:
        if name in self.labels:
            raise ValueError(f"duplicate label {name}")
        self.labels[name] = self.pc

    def emit(self, *values: int) -> None:
        self.data.extend(v & 0xFF for v in values)

    def word(self, value: int) -> None:
        self.emit(value, value >> 8)

    def absolute_fixup(self, opcode: int, label: str) -> None:
        self.emit(opcode)
        self.fixups.append(("absolute", len(self.data), label))
        self.emit(0, 0)

    def call(self, target: int | str) -> None:
        if isinstance(target, int):
            self.emit(0xCD)
            self.word(target)
        else:
            self.absolute_fixup(0xCD, target)

    def jump(self, label: str, condition: Optional[str] = None) -> None:
        opcode = {None: 0xC3, "z": 0xCA, "nz": 0xC2, "c": 0xDA, "nc": 0xD2}[condition]
        self.absolute_fixup(opcode, label)

    def relative_jump(self, label: str, condition: Optional[str] = None) -> None:
        opcode = {None: 0x18, "z": 0x28, "nz": 0x20, "c": 0x38, "nc": 0x30}[condition]
        self.emit(opcode)
        self.fixups.append(("relative", len(self.data), label))
        self.emit(0)

    def finish(self) -> bytes:
        for kind, pos, label in self.fixups:
            target = self.labels[label]
            if kind == "absolute":
                self.data[pos:pos + 2] = struct.pack("<H", target)
            else:
                displacement = target - (self.ORIGIN + pos + 1)
                if not -128 <= displacement <= 127:
                    raise ValueError(f"JR {label} out of range: {displacement}")
                self.data[pos] = displacement & 0xFF
        return bytes(self.data)


def load_a_abs(a: Assembler, address: int) -> None:
    a.emit(0x3A); a.word(address)


def store_a_abs(a: Assembler, address: int) -> None:
    a.emit(0x32); a.word(address)


def load_hl_abs(a: Assembler, address: int) -> None:
    a.emit(0x2A); a.word(address)


def store_hl_abs(a: Assembler, address: int) -> None:
    a.emit(0x22); a.word(address)


def load_hl(a: Assembler, value: int) -> None:
    a.emit(0x21); a.word(value)


def load_de(a: Assembler, value: int) -> None:
    a.emit(0x11); a.word(value)


def load_bc(a: Assembler, value: int) -> None:
    a.emit(0x01); a.word(value)


def output_a(a: Assembler, port: int) -> None:
    a.emit(0xD3, port)


def psg_constant(a: Assembler, register: int, value: int) -> None:
    a.emit(0x3E, register); output_a(a, 0xA0)
    a.emit(0x3E, value); output_a(a, 0xA1)


def request_page(a: Assembler) -> None:
    """Load the one-byte HSC next-page field into both A and ABI-1 HL."""
    load_a_abs(a, TRACK + 12)
    a.emit(0x6F, 0x26, 0x00)  # LD L,A / LD H,0; A remains the low byte too.
    a.call(PAGE_GATEWAY)


def emit_wave_copy(a: Assembler, source_channel: int, destination: int) -> None:
    """Consume one waveform ID from (HL) and copy its 32-byte dictionary entry."""
    a.emit(0x7E, 0x23, 0xE5, 0x6F, 0x26, 0x00)
    for _ in range(5):
        a.emit(0x29)
    load_bc(a, WAVE); a.emit(0x09)
    load_de(a, destination); load_bc(a, 32)
    a.emit(0xED, 0xB0, 0xE1)


def emit_common_header(a: Assembler) -> None:
    a.label("play")
    load_a_abs(a, ENDED); a.emit(0xB7, 0xC0)
    load_a_abs(a, WAIT); a.emit(0xB7)
    a.relative_jump("apply_event", "z")
    a.emit(0x3D); store_a_abs(a, WAIT); a.emit(0xC9)

    a.label("load_chunk_start")
    load_hl_abs(a, TRACK + 8); load_de(a, TRACK); a.emit(0x19)
    store_hl_abs(a, LOOPPTR)
    load_hl_abs(a, TRACK + 10); load_de(a, TRACK); a.emit(0x19)
    a.emit(0x7E, 0x23); store_a_abs(a, WAIT); store_hl_abs(a, PTR)
    a.emit(0xB7, 0xC0)
    a.jump("apply_event")

    a.label("apply_event")
    load_hl_abs(a, PTR)
    a.emit(0x7E, 0x23); store_a_abs(a, FM)
    a.emit(0x7E, 0x23); store_a_abs(a, VM)
    a.emit(0x7E, 0x23); store_a_abs(a, WM)


def emit_psg_frequency_and_noise(a: Assembler) -> None:
    load_a_abs(a, FM); a.emit(0xE6, 0x20)
    a.relative_jump("psg_frequency_done", "z")
    a.emit(0x5E, 0x23, 0x56, 0x23)
    a.emit(0x3E, 0); output_a(a, 0xA0); a.emit(0x7B); output_a(a, 0xA1)
    a.emit(0x3E, 1); output_a(a, 0xA0); a.emit(0x7A); output_a(a, 0xA1)
    a.label("psg_frequency_done")

    load_a_abs(a, FM); a.emit(0xE6, 0x40)
    a.relative_jump("noise_frequency_done", "z")
    a.emit(0x5E, 0x23, 0x3E, 6); output_a(a, 0xA0); a.emit(0x7B); output_a(a, 0xA1)
    a.label("noise_frequency_done")


def emit_psg_volumes(a: Assembler) -> None:
    load_a_abs(a, VM); a.emit(0xE6, 0x20)
    a.relative_jump("psg_volume_done", "z")
    a.emit(0x5E, 0x23, 0x3E, 8); output_a(a, 0xA0); a.emit(0x7B); output_a(a, 0xA1)
    a.label("psg_volume_done")

    load_a_abs(a, VM); a.emit(0xE6, 0x40)
    a.relative_jump("noise_volume_done", "z")
    a.emit(0x5E, 0x23, 0x3E, 9); output_a(a, 0xA0); a.emit(0x7B); output_a(a, 0xA1)
    a.label("noise_volume_done")


def emit_stream_tail(a: Assembler) -> None:
    a.emit(0x7E, 0x23, 0xFE, 0xFF)
    a.relative_jump("stream_end", "z")
    store_a_abs(a, WAIT); store_hl_abs(a, PTR); a.emit(0xC9)

    a.label("stream_end")
    load_a_abs(a, TRACK + 4); a.emit(0xE6, 0x08)
    a.relative_jump("local_end", "z")
    load_a_abs(a, TRACK + 4); a.emit(0xE6, 0x10)
    a.relative_jump("ordinary_continuation", "z")

    request_page(a)
    load_hl_abs(a, TRACK + 8); load_de(a, TRACK); a.emit(0x19)
    store_hl_abs(a, PTR); a.emit(0xAF); store_a_abs(a, WAIT); a.emit(0xC9)

    a.label("ordinary_continuation")
    request_page(a)
    load_hl_abs(a, TRACK + 10); load_de(a, TRACK); a.emit(0x19)
    a.emit(0x7E, 0x23); store_a_abs(a, WAIT); store_hl_abs(a, PTR); a.emit(0xC9)

    a.label("local_end")
    load_a_abs(a, TRACK + 4); a.emit(0xE6, 1)
    a.relative_jump("final_end", "z")
    load_hl_abs(a, LOOPPTR); store_hl_abs(a, PTR)
    a.emit(0xAF); store_a_abs(a, WAIT); a.emit(0xC9)

    a.label("final_end")
    a.call("silence"); a.emit(0x3E, 1); store_a_abs(a, ENDED); a.emit(0xC9)


def finish_engine(a: Assembler, max_size: int = 0x700) -> Tuple[bytes, Dict[str, int]]:
    code = a.finish()
    if len(code) > max_size:
        raise ValueError(f"engine too large: {len(code)} > {max_size}")
    return code, a.labels


def build_sccplus_engine() -> Tuple[bytes, Dict[str, int]]:
    a = Assembler()
    a.label("init")
    a.call("silence")
    a.emit(0xAF); store_a_abs(a, ENDED)
    a.emit(0x3E, 0x20); store_a_abs(a, SCCP_MODE)
    a.emit(0x3E, 0x80); store_a_abs(a, SCCP_ENABLE)
    psg_constant(a, 7, 0x2E)
    a.emit(0x3E, 0x1F); store_a_abs(a, SCCP_KEY)
    a.call("load_chunk_start"); a.emit(0xC9)

    emit_common_header(a)

    for i in range(5):
        load_a_abs(a, WM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"wave_{i}_done", "z")
        emit_wave_copy(a, i, SCCP_WAVE + 32 * i)
        a.label(f"wave_{i}_done")

    for i in range(5):
        load_a_abs(a, FM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"frequency_{i}_done", "z")
        a.emit(0x7E, 0x23); store_a_abs(a, SCCP_FREQ + 2 * i)
        a.emit(0x7E, 0x23, 0xE6, 0x0F); store_a_abs(a, SCCP_FREQ + 2 * i + 1)
        a.label(f"frequency_{i}_done")

    emit_psg_frequency_and_noise(a)

    for i in range(5):
        load_a_abs(a, VM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"volume_{i}_done", "z")
        a.emit(0x7E, 0x23, 0xE6, 0x0F); store_a_abs(a, SCCP_VOL + i)
        a.label(f"volume_{i}_done")

    emit_psg_volumes(a)
    emit_stream_tail(a)

    a.label("silence")
    a.emit(0xAF); load_hl(a, SCCP_VOL); a.emit(0x06, 6)
    a.label("silence_loop")
    a.emit(0x77, 0x23, 0x10)
    a.fixups.append(("relative", len(a.data), "silence_loop")); a.emit(0)
    for reg in (8, 9, 10):
        psg_constant(a, reg, 0)
    a.emit(0xC9)
    return finish_engine(a)


def build_normal_scc_engine() -> Tuple[bytes, Dict[str, int]]:
    a = Assembler()
    a.label("init")
    a.call("silence")
    a.emit(0xAF); store_a_abs(a, ENDED)
    a.emit(0x3E, 0x3F); store_a_abs(a, SCC_ENABLE)
    psg_constant(a, 7, 0x2E)
    a.emit(0x3E, 0x1F); store_a_abs(a, SCC_KEY)
    a.call("load_chunk_start"); a.emit(0xC9)

    emit_common_header(a)

    for i in range(4):
        load_a_abs(a, WM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"wave_{i}_done", "z")
        emit_wave_copy(a, i, SCC_WAVE + 32 * i)
        a.label(f"wave_{i}_done")

    for i in range(5):
        load_a_abs(a, FM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"frequency_{i}_done", "z")
        a.emit(0x7E, 0x23); store_a_abs(a, SCC_FREQ + 2 * i)
        a.emit(0x7E, 0x23, 0xE6, 0x0F); store_a_abs(a, SCC_FREQ + 2 * i + 1)
        a.label(f"frequency_{i}_done")

    emit_psg_frequency_and_noise(a)

    for i in range(5):
        load_a_abs(a, VM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"volume_{i}_done", "z")
        a.emit(0x7E, 0x23, 0xE6, 0x0F); store_a_abs(a, SCC_VOL + i)
        a.label(f"volume_{i}_done")

    emit_psg_volumes(a)
    emit_stream_tail(a)

    a.label("silence")
    a.emit(0xAF); load_hl(a, SCC_VOL); a.emit(0x06, 6)
    a.label("silence_loop")
    a.emit(0x77, 0x23, 0x10)
    a.fixups.append(("relative", len(a.data), "silence_loop")); a.emit(0)
    for reg in (8, 9, 10):
        psg_constant(a, reg, 0)
    a.emit(0xC9)
    return finish_engine(a)


def build_dual_scc_engine() -> Tuple[bytes, Dict[str, int]]:
    """Five independent HSC1 wavetable voices: A0-A2 and B0-B1."""
    a = Assembler()
    a.label("init")
    a.call("silence")
    a.emit(0xAF); store_a_abs(a, ENDED)
    a.call(DUAL_SELECT_A)
    a.emit(0x3E, 0x1F); store_a_abs(a, SCC_KEY)
    a.call(DUAL_SELECT_B)
    a.emit(0x3E, 0x1F); store_a_abs(a, SCC_KEY)
    a.call(DUAL_RESTORE)
    psg_constant(a, 7, 0x2E)
    a.call("load_chunk_start"); a.emit(0xC9)

    emit_common_header(a)

    # Wave IDs are consumed in HSC1 channel order.  The two cartridges avoid
    # normal SCC's channel-4/5 shared-waveform limitation entirely.
    load_a_abs(a, WM); a.emit(0xE6, 0x07)
    a.relative_jump("waves_a_done", "z")
    a.call(DUAL_SELECT_A)
    for i in range(3):
        load_a_abs(a, WM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"wave_a_{i}_done", "z")
        emit_wave_copy(a, i, SCC_WAVE + 32 * i)
        a.label(f"wave_a_{i}_done")
    a.label("waves_a_done")

    load_a_abs(a, WM); a.emit(0xE6, 0x18)
    a.relative_jump("waves_b_done", "z")
    a.call(DUAL_SELECT_B)
    for src, dest in ((3, 0), (4, 1)):
        load_a_abs(a, WM); a.emit(0xE6, 1 << src)
        a.relative_jump(f"wave_b_{src}_done", "z")
        emit_wave_copy(a, src, SCC_WAVE + 32 * dest)
        a.label(f"wave_b_{src}_done")
    a.label("waves_b_done")

    load_a_abs(a, FM); a.emit(0xE6, 0x07)
    a.relative_jump("freq_a_done", "z")
    a.call(DUAL_SELECT_A)
    for i in range(3):
        load_a_abs(a, FM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"frequency_a_{i}_done", "z")
        a.emit(0x7E, 0x23); store_a_abs(a, SCC_FREQ + 2 * i)
        a.emit(0x7E, 0x23, 0xE6, 0x0F); store_a_abs(a, SCC_FREQ + 2 * i + 1)
        a.label(f"frequency_a_{i}_done")
    a.label("freq_a_done")

    load_a_abs(a, FM); a.emit(0xE6, 0x18)
    a.relative_jump("freq_b_done", "z")
    a.call(DUAL_SELECT_B)
    for src, dest in ((3, 0), (4, 1)):
        load_a_abs(a, FM); a.emit(0xE6, 1 << src)
        a.relative_jump(f"frequency_b_{src}_done", "z")
        a.emit(0x7E, 0x23); store_a_abs(a, SCC_FREQ + 2 * dest)
        a.emit(0x7E, 0x23, 0xE6, 0x0F); store_a_abs(a, SCC_FREQ + 2 * dest + 1)
        a.label(f"frequency_b_{src}_done")
    a.label("freq_b_done")

    # HSC1 stores PSG frequency/noise immediately after all five SCC
    # frequency values and before the SCC/PSG volume fields. Restore mapper RAM
    # before consuming those PSG bytes, then select the cartridges again for
    # their volume writes.
    a.call(DUAL_RESTORE)
    emit_psg_frequency_and_noise(a)

    load_a_abs(a, VM); a.emit(0xE6, 0x07)
    a.relative_jump("vol_a_done", "z")
    a.call(DUAL_SELECT_A)
    for i in range(3):
        load_a_abs(a, VM); a.emit(0xE6, 1 << i)
        a.relative_jump(f"volume_a_{i}_done", "z")
        a.emit(0x7E, 0x23, 0xE6, 0x0F); store_a_abs(a, SCC_VOL + i)
        a.label(f"volume_a_{i}_done")
    a.label("vol_a_done")

    load_a_abs(a, VM); a.emit(0xE6, 0x18)
    a.relative_jump("vol_b_done", "z")
    a.call(DUAL_SELECT_B)
    for src, dest in ((3, 0), (4, 1)):
        load_a_abs(a, VM); a.emit(0xE6, 1 << src)
        a.relative_jump(f"volume_b_{src}_done", "z")
        a.emit(0x7E, 0x23, 0xE6, 0x0F); store_a_abs(a, SCC_VOL + dest)
        a.label(f"volume_b_{src}_done")
    a.label("vol_b_done")

    a.call(DUAL_RESTORE)
    emit_psg_volumes(a)
    emit_stream_tail(a)

    a.label("silence")
    a.call(DUAL_SELECT_A)
    a.emit(0xAF); load_hl(a, SCC_VOL); a.emit(0x06, 6)
    a.label("silence_a_loop")
    a.emit(0x77, 0x23, 0x10)
    a.fixups.append(("relative", len(a.data), "silence_a_loop")); a.emit(0)
    a.call(DUAL_SELECT_B)
    a.emit(0xAF); load_hl(a, SCC_VOL); a.emit(0x06, 6)
    a.label("silence_b_loop")
    a.emit(0x77, 0x23, 0x10)
    a.fixups.append(("relative", len(a.data), "silence_b_loop")); a.emit(0)
    a.call(DUAL_RESTORE)
    for reg in (8, 9, 10):
        psg_constant(a, reg, 0)
    a.emit(0xC9)
    return finish_engine(a)


def make_template(code: bytes) -> bytes:
    page = bytearray(PAGE_SIZE)
    page[:len(code)] = code
    return bytes(page)


def extract_hsc0(page: bytes, converter) -> bytes:
    data = page[TRACK_OFFSET:]
    if data[:4] != b"HSC0":
        raise ValueError("normal-SCC page does not contain HSC0")
    cursor = struct.unpack_from("<H", data, 10)[0]
    while True:
        if cursor >= len(data):
            raise ValueError("HSC0 stream exceeds page")
        delay = data[cursor]
        cursor += 1
        if delay == 0xFF:
            break
        if cursor + 3 > len(data):
            raise ValueError("truncated HSC0 event")
        fm, vm, wm = data[cursor:cursor + 3]
        cursor += 3
        cursor += sum((wm >> i) & 1 for i in range(4))
        cursor += 2 * sum((fm >> i) & 1 for i in range(6))
        cursor += (fm >> 6) & 1
        cursor += sum((vm >> i) & 1 for i in range(7))
    block = bytes(data[:cursor])
    converter.validate_hsc0(block)
    return block


def concatenate_blocks(blocks: Sequence[bytes]) -> Tuple[bytes, List[int]]:
    raw = bytearray()
    offsets: List[int] = []
    for block in blocks:
        offsets.append(len(raw))
        raw.extend(block)
    return bytes(raw), offsets


def build_kzb1(raw: bytes, converter, block_size: int = 0x4000) -> Tuple[bytes, dict]:
    chunks = [raw[i:i + block_size] for i in range(0, len(raw), block_size)]
    table_size = 16 * len(chunks)
    data_offset = 16 + table_size
    descriptors = bytearray(table_size)
    payloads: List[bytes] = []
    cursor = data_offset
    raw_total = packed_total = 0
    for i, chunk in enumerate(chunks):
        packed = converter.zx0_compress(chunk)
        # KZB1 defines every block as an independent ZX0 stream.
        if converter.zx0_decompress(packed, len(chunk)) != chunk:
            raise ValueError("KZB1 ZX0 round-trip failed")
        struct.pack_into("<IIII", descriptors, i * 16,
                         cursor, len(packed), len(chunk), crc32(chunk))
        payloads.append(packed)
        cursor += len(packed)
        raw_total += len(chunk)
        packed_total += len(packed)
    header = bytearray(16)
    header[:4] = b"KZB1"
    struct.pack_into("<HHII", header, 4, 16, len(chunks), len(raw), 16)
    container = bytes(header + descriptors + b"".join(payloads))
    return container, {
        "blocks": len(chunks),
        "raw_bytes": raw_total,
        "zx0_bytes": packed_total,
        "container_bytes": len(container),
    }


def build_rmp1(resource_index: int, source_offset: int, byte_count: int) -> bytes:
    payload = bytearray(32)
    payload[:4] = b"RMP1"
    struct.pack_into("<HHHHI", payload, 4, 16, 1, 16, 0, 0)
    struct.pack_into("<HHBBHII", payload, 16,
                     TRACK_OFFSET, byte_count, 0, 0, resource_index,
                     source_offset, 0)
    return bytes(payload)


def build_hvar(track_count: int) -> bytes:
    logical_table_offset = 24
    candidate_table_offset = logical_table_offset + track_count * 12
    payload = bytearray(candidate_table_offset + track_count * 3 * 8)
    payload[:4] = b"HVR1"
    struct.pack_into("<HHHHHHII", payload, 4,
                     24, 1, track_count, track_count * 3, 12, 8,
                     logical_table_offset, candidate_table_offset)
    for i in range(track_count):
        struct.pack_into("<HHHHI", payload, logical_table_offset + i * 12,
                         i, i * 3, 3, 0, 0)
        candidates = (
            (2 * track_count + i, 300),
            (track_count + i, 200),
            (i, 100),
        )
        for j, (implementation, rank) in enumerate(candidates):
            struct.pack_into("<HHHH", payload, candidate_table_offset + (i * 3 + j) * 8,
                             implementation, rank, 0, 0)
    return bytes(payload)


@dataclass
class ObjectPayload:
    compression: int
    stored: bytes
    raw: bytes


def compress_object(raw: bytes, converter) -> ObjectPayload:
    packed = converter.zx0_compress(raw)
    if len(packed) < len(raw):
        return ObjectPayload(KSP_COMPRESSION_ZX0, packed, raw)
    return ObjectPayload(KSP_COMPRESSION_NONE, raw, raw)


def update_meta(source_meta: bytes, hsc1_stats: dict, hsc0_stats: dict) -> bytes:
    lines = []
    seen = set()
    for raw_line in source_meta.decode("utf-8", "replace").splitlines():
        if "=" not in raw_line:
            continue
        key = raw_line.split("=", 1)[0]
        if key in {"system", "conversion", "page_encodings", "hardware", "notes"}:
            continue
        if key not in seen:
            lines.append(raw_line)
            seen.add(key)
    lines.extend([
        "system=PC Engine to MSX SCC / SCC+ / dual-SCC adaptive package",
        "hardware=MSX PSG + normal SCC fallback; SCC+; dual normal SCC",
        "conversion=KSP 1.02 HVAR hardware variants",
        "page_encodings=RMP1 resource-range maps",
        "music_storage=one shared HSC1 resource for SCC+ and dual SCC; one HSC0 normal-SCC resource",
        "variant_priority=dual SCC 300; SCC+ 200; normal SCC 100",
        "dual_scc_mapping=HSC1 voices 1-3 on SCC A and voices 4-5 on SCC B; PSG tone/noise preserved",
        "notes=Dual SCC is lossless relative to the supplied SCC+ KSP; the supplied KSP no longer contains the original sixth HuC6280 wavetable waveform.",
        f"hsc1_logical_bytes={hsc1_stats['raw_bytes']}",
        f"hsc0_logical_bytes={hsc0_stats['raw_bytes']}",
    ])
    return ("\n".join(lines) + "\n").encode("utf-8")


def make_sparse_page(template: bytes, block: bytes) -> bytes:
    page = bytearray(template)
    page[TRACK_OFFSET:TRACK_OFFSET + len(block)] = block
    return bytes(page)


def build_package(sccplus_path: Path, normal_path: Path, converter_path: Path,
                  output_path: Path, report_path: Path) -> dict:
    converter = load_converter(converter_path)
    source = converter.parse_ksp(sccplus_path)
    normal = converter.parse_ksp(normal_path)
    if len(source.engines) != 1 or len(normal.engines) != 1:
        raise ValueError("expected one source engine in each input")
    if len(source.pages) != len(normal.pages) or len(source.tracks) != len(normal.tracks):
        raise ValueError("SCC+ and normal-SCC inputs have different dimensions")

    page_count_each = len(source.pages)
    track_count_each = len(source.tracks)

    hsc1_blocks = [converter.extract_hsc1_page(page)[0] for page in source.pages]
    hsc0_blocks = [extract_hsc0(page, converter) for page in normal.pages]
    hsc1_raw, hsc1_offsets = concatenate_blocks(hsc1_blocks)
    hsc0_raw, hsc0_offsets = concatenate_blocks(hsc0_blocks)
    hsc1_kzb, hsc1_stats = build_kzb1(hsc1_raw, converter)
    hsc0_kzb, hsc0_stats = build_kzb1(hsc0_raw, converter)

    normal_code, normal_labels = build_normal_scc_engine()
    plus_code, plus_labels = build_sccplus_engine()
    dual_code, dual_labels = build_dual_scc_engine()
    templates = [make_template(normal_code), make_template(plus_code), make_template(dual_code)]
    labels = [normal_labels, plus_labels, dual_labels]
    template_objects = [compress_object(t, converter) for t in templates]

    final_pages: List[bytes] = []
    for template, blocks in ((templates[0], hsc0_blocks),
                             (templates[1], hsc1_blocks),
                             (templates[2], hsc1_blocks)):
        final_pages.extend(make_sparse_page(template, b) for b in blocks)

    # RMP1 payloads: HSC1 maps are physically shared by SCC+ and dual-SCC page entries.
    hsc1_maps = [build_rmp1(0, off, len(block)) for off, block in zip(hsc1_offsets, hsc1_blocks)]
    hsc0_maps = [build_rmp1(1, off, len(block)) for off, block in zip(hsc0_offsets, hsc0_blocks)]
    unique_map_objects = [compress_object(m, converter) for m in hsc1_maps + hsc0_maps]

    hvar = build_hvar(track_count_each)
    hvar_object = compress_object(hvar, converter)
    source_meta = next((r.payload for r in source.resources if r.kind == b"META"), b"title=Parodius Da!\n")
    meta = update_meta(source_meta, hsc1_stats, hsc0_stats)
    meta_object = compress_object(meta, converter)

    strings = bytearray()
    string_offsets: Dict[str, int] = {}
    def add_string(value: str) -> int:
        if value in string_offsets:
            return string_offsets[value]
        offset = len(strings)
        strings.extend(value.encode("utf-8") + b"\0")
        string_offsets[value] = offset
        return offset

    engine_names = [
        "Parodius Da! normal SCC dynamic waveform-pairing fallback",
        "Parodius Da! SCC+ five-independent-waveform engine",
        "Parodius Da! dual SCC five-independent-waveform engine",
    ]
    engine_name_offsets = [add_string(x) for x in engine_names]
    title_offsets = [add_string(t.title) for t in source.tracks]

    engine_count = 3
    total_pages = page_count_each * 3
    total_tracks = track_count_each * 3
    resource_count = 4
    engine_offset = 80
    page_offset = engine_offset + engine_count * 64
    track_offset = page_offset + total_pages * 24
    resource_offset = track_offset + total_tracks * 32
    string_offset = resource_offset + resource_count * 32
    payload_offset = string_offset + len(strings)

    # Payload order: templates, unique maps (HSC1 then HSC0), resources.
    cursor = payload_offset
    template_offsets = []
    for obj in template_objects:
        template_offsets.append(cursor); cursor += len(obj.stored)
    map_offsets = []
    for obj in unique_map_objects:
        map_offsets.append(cursor); cursor += len(obj.stored)
    hsc1_resource_offset = cursor; cursor += len(hsc1_kzb)
    hsc0_resource_offset = cursor; cursor += len(hsc0_kzb)
    hvar_offset = cursor; cursor += len(hvar_object.stored)
    meta_offset = cursor; cursor += len(meta_object.stored)
    file_size = cursor

    engine_table = bytearray(engine_count * 64)
    hardware = [KSP_HARDWARE_PSG | KSP_HARDWARE_SCC,
                KSP_HARDWARE_PSG | KSP_HARDWARE_SCCPLUS,
                KSP_HARDWARE_PSG | KSP_HARDWARE_DUAL_SCC]
    for i in range(engine_count):
        off = i * 64
        struct.pack_into("<II", engine_table, off, KSP_ENGINE_DYNAMIC_PAGES, hardware[i])
        struct.pack_into("<HHHHHHHHHHHH", engine_table, off + 8,
                         1, 60, PAGE_LOAD, PAGE_SIZE,
                         labels[i]["init"], labels[i]["play"], 0,
                         PAGE_GATEWAY, TRACK, i * page_count_each,
                         page_count_each, NULL16)
        engine_table[off + 32] = template_objects[i].compression
        engine_table[off + 33:off + 36] = b"\0\0\0"
        struct.pack_into("<IIIII", engine_table, off + 36,
                         template_offsets[i], len(template_objects[i].stored), PAGE_SIZE,
                         crc32(templates[i]), engine_name_offsets[i])

    page_table = bytearray(total_pages * 24)
    for global_index in range(total_pages):
        engine_index = global_index // page_count_each
        local_index = global_index % page_count_each
        if engine_index == 0:
            map_obj_index = page_count_each + local_index
        else:
            map_obj_index = local_index
        obj = unique_map_objects[map_obj_index]
        struct.pack_into("<HBBHHIIII", page_table, global_index * 24,
                         engine_index, KSP_PAGE_RESOURCE_MAP, obj.compression, 0, 0,
                         map_offsets[map_obj_index], len(obj.stored), len(obj.raw),
                         crc32(final_pages[global_index]))

    track_table = bytearray(total_tracks * 32)
    for profile in range(3):
        for i, track in enumerate(source.tracks):
            out_index = profile * track_count_each + i
            page_base = profile * page_count_each
            flags = track.flags if profile == 0 else (track.flags | KSP_TRACK_HIDDEN)
            struct.pack_into("<HHHHHHIIIII", track_table, out_index * 32,
                             page_base + track.page, track.song, flags,
                             NULL16, NULL16, 0, title_offsets[i],
                             track.duration, track.loop_start, track.loop_end, track.fade)

    resource_table = bytearray(resource_count * 32)
    data_flags = KSP_RESOURCE_REQUIRED | KSP_RESOURCE_STREAMABLE | KSP_RESOURCE_PAGE_SOURCE
    for index, (offset, stored, raw) in enumerate(((hsc1_resource_offset, hsc1_kzb, hsc1_raw),
                                                   (hsc0_resource_offset, hsc0_kzb, hsc0_raw))):
        off = index * 32
        resource_table[off:off + 4] = b"DATA"
        struct.pack_into("<HBBIIIIII", resource_table, off + 4,
                         data_flags, KSP_COMPRESSION_ZX0_BLOCKS, 0,
                         offset, len(stored), len(raw), crc32(raw), index, 0)
    resource_table[64:68] = b"HVAR"
    struct.pack_into("<HBBIIIIII", resource_table, 68,
                     0, hvar_object.compression, 0,
                     hvar_offset, len(hvar_object.stored), len(hvar), crc32(hvar), 0, 0)
    resource_table[96:100] = b"META"
    struct.pack_into("<HBBIIIIII", resource_table, 100,
                     0, meta_object.compression, 0,
                     meta_offset, len(meta_object.stored), len(meta), crc32(meta), 0, 0)

    header = bytearray(80)
    header[:4] = b"KSP1"
    struct.pack_into("<HHII", header, 4, 80, 2, 0, file_size)
    struct.pack_into("<IHH", header, 16, engine_offset, engine_count, 64)
    struct.pack_into("<IHH", header, 24, page_offset, total_pages, 24)
    struct.pack_into("<IHH", header, 32, track_offset, total_tracks, 32)
    struct.pack_into("<IHH", header, 40, resource_offset, resource_count, 32)
    struct.pack_into("<II", header, 48, string_offset, len(strings))
    struct.pack_into("<HHHH", header, 56, source.default_track, 3, NULL16, 0)
    index_bytes = bytes(engine_table + page_table + track_table + resource_table + strings)
    struct.pack_into("<I", header, 68, crc32(index_bytes))
    header_for_crc = bytearray(header)
    struct.pack_into("<I", header_for_crc, 64, 0)
    struct.pack_into("<I", header, 64, crc32(header_for_crc))

    output = (bytes(header) + bytes(engine_table) + bytes(page_table) +
              bytes(track_table) + bytes(resource_table) + bytes(strings) +
              b"".join(obj.stored for obj in template_objects) +
              b"".join(obj.stored for obj in unique_map_objects) +
              hsc1_kzb + hsc0_kzb + hvar_object.stored + meta_object.stored)
    if len(output) != file_size:
        raise AssertionError(f"output size mismatch {len(output)} != {file_size}")
    output_path.write_bytes(output)

    report = validate_package(output_path, converter, final_pages, hsc1_raw, hsc0_raw)
    naive_music_bytes = len(hsc1_raw) * 2 + len(hsc0_raw)
    shared_music_bytes = len(hsc1_raw) + len(hsc0_raw)
    report.update({
        "input_sccplus": sccplus_path.name,
        "input_normal_scc": normal_path.name,
        "output": output_path.name,
        "output_bytes": len(output),
        "output_sha256": sha256(output),
        "engines": {
            "normal_scc": {"code_bytes": len(normal_code), "hardware_flags": hardware[0]},
            "sccplus": {"code_bytes": len(plus_code), "hardware_flags": hardware[1]},
            "dual_scc": {"code_bytes": len(dual_code), "hardware_flags": hardware[2],
                         "voice_mapping": "A channels 1-3; B channels 1-2; PSG preserved"},
        },
        "storage": {
            "hsc1_raw_bytes_shared_by_sccplus_and_dual": len(hsc1_raw),
            "hsc1_kzb1_bytes": len(hsc1_kzb),
            "hsc0_raw_bytes": len(hsc0_raw),
            "hsc0_kzb1_bytes": len(hsc0_kzb),
            "naive_uncompressed_music_bytes": naive_music_bytes,
            "shared_uncompressed_music_bytes": shared_music_bytes,
            "uncompressed_music_bytes_saved": naive_music_bytes - shared_music_bytes,
            "hsc1_kzb1": hsc1_stats,
            "hsc0_kzb1": hsc0_stats,
            "rmp1_unique_maps": len(unique_map_objects),
            "rmp1_page_entries": total_pages,
            "sccplus_dual_map_payloads_physically_shared": page_count_each,
        },
        "quality": {
            "dual_scc": "Five HSC1 SCC+ wave voices are preserved independently across two normal SCCs; PSG tone/noise remain PSG.",
            "sccplus": "Five independent SCC+ waveforms, equivalent event data to the source package.",
            "normal_scc": "Corrected dynamic waveform pairing; channels 4/5 share the closest available waveform.",
            "source_limit": "The supplied HSC1 KSP does not retain the original sixth HuC6280 wavetable waveform, so dual SCC cannot reconstruct more than the supplied SCC+ representation.",
        },
    })
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def u16(data: bytes, off: int) -> int:
    return struct.unpack_from("<H", data, off)[0]


def u32(data: bytes, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def decode_kzb1(payload: bytes, logical_size: int, converter) -> bytes:
    if payload[:4] != b"KZB1" or u16(payload, 4) != 16:
        raise ValueError("invalid KZB1")
    count = u16(payload, 6)
    if u32(payload, 8) != logical_size or u32(payload, 12) != 16:
        raise ValueError("invalid KZB1 header")
    out = bytearray()
    for i in range(count):
        off, packed, raw, expected_crc = struct.unpack_from("<IIII", payload, 16 + i * 16)
        if off + packed > len(payload):
            raise ValueError("KZB1 block outside resource")
        chunk = converter.zx0_decompress(payload[off:off + packed], raw)
        if crc32(chunk) != expected_crc:
            raise ValueError("KZB1 block CRC mismatch")
        out.extend(chunk)
    if len(out) != logical_size:
        raise ValueError("KZB1 logical size mismatch")
    return bytes(out)


def validate_package(path: Path, converter, expected_pages: Sequence[bytes],
                     expected_hsc1: bytes, expected_hsc0: bytes) -> dict:
    data = path.read_bytes()
    if len(data) < 80 or data[:4] != b"KSP1" or u16(data, 4) != 80 or u16(data, 6) != 2:
        raise ValueError("not strict KSP 1.02")
    if u32(data, 12) != len(data):
        raise ValueError("file size mismatch")
    h = bytearray(data[:80]); stored = u32(h, 64); struct.pack_into("<I", h, 64, 0)
    if crc32(h) != stored:
        raise ValueError("header CRC mismatch")
    eo, ec, es = u32(data,16),u16(data,20),u16(data,22)
    po, pc, ps = u32(data,24),u16(data,28),u16(data,30)
    to, tc, ts = u32(data,32),u16(data,36),u16(data,38)
    ro, rc, rs = u32(data,40),u16(data,44),u16(data,46)
    so, ss = u32(data,48),u32(data,52)
    if (ec,pc,tc,rc)!=(3,129,114,4) or (es,ps,ts,rs)!=(64,24,32,32):
        raise ValueError("unexpected table dimensions")
    index = data[eo:eo+ec*es]+data[po:po+pc*ps]+data[to:to+tc*ts]+data[ro:ro+rc*rs]+data[so:so+ss]
    if crc32(index) != u32(data,68):
        raise ValueError("index CRC mismatch")

    resources = []
    for i in range(rc):
        e = data[ro+i*32:ro+(i+1)*32]
        kind=e[:4]; flags=u16(e,4); comp=e[6]; off=u32(e,8); packed=u32(e,12); raw=u32(e,16); c=u32(e,20)
        payload=data[off:off+packed]
        if len(payload)!=packed: raise ValueError("resource outside file")
        if comp==0: logical=payload
        elif comp==1: logical=converter.zx0_decompress(payload,raw)
        elif comp==2: logical=decode_kzb1(payload,raw,converter)
        else: raise ValueError("unknown resource compression")
        if len(logical)!=raw or crc32(logical)!=c: raise ValueError("resource validation failed")
        resources.append((kind,flags,logical))
    if resources[0][2]!=expected_hsc1 or resources[1][2]!=expected_hsc0:
        raise ValueError("shared music resources differ from input blocks")
    if resources[2][0]!=b"HVAR" or resources[2][2][:4]!=b"HVR1":
        raise ValueError("missing HVAR/HVR1")

    templates=[]
    engines=[]
    for i in range(ec):
        e=data[eo+i*64:eo+(i+1)*64]
        comp=e[32]; off=u32(e,36); packed=u32(e,40); raw=u32(e,44)
        payload=data[off:off+packed]
        template=payload if comp==0 else converter.zx0_decompress(payload,raw)
        if len(template)!=PAGE_SIZE or crc32(template)!=u32(e,48): raise ValueError("template validation failed")
        templates.append(template); engines.append((u32(e,4),u16(e,26),u16(e,28)))
    if [x[0] for x in engines] != [3,5,9]:
        raise ValueError("hardware flags mismatch")

    reconstructed=[]
    for i in range(pc):
        e=data[po+i*24:po+(i+1)*24]
        owner=u16(e,0); encoding=e[2]; comp=e[3]; off=u32(e,8); packed=u32(e,12); raw=u32(e,16)
        if encoding!=KSP_PAGE_RESOURCE_MAP: raise ValueError("page is not RMP1")
        payload=data[off:off+packed]
        rmp=payload if comp==0 else converter.zx0_decompress(payload,raw)
        if rmp[:4]!=b"RMP1" or u16(rmp,6)!=1 or u16(rmp,8)!=16: raise ValueError("bad RMP1")
        dest,count,typ,flags,residx,source_off,reserved=struct.unpack_from("<HHBBHII",rmp,16)
        if typ!=0 or flags or reserved or dest+count>PAGE_SIZE: raise ValueError("bad RMP1 record")
        page=bytearray(templates[owner]); page[dest:dest+count]=resources[residx][2][source_off:source_off+count]
        page=bytes(page)
        if crc32(page)!=u32(e,20): raise ValueError("page CRC mismatch")
        reconstructed.append(page)
    if reconstructed != list(expected_pages):
        raise ValueError("page reconstruction mismatch")

    hvar=resources[2][2]
    if u16(hvar,8)!=38 or u16(hvar,10)!=114 or u16(hvar,12)!=12 or u16(hvar,14)!=8:
        raise ValueError("HVAR dimensions mismatch")
    lto=u32(hvar,16); cto=u32(hvar,20)
    for i in range(38):
        logical,first,count,flags,reserved=struct.unpack_from("<HHHHI",hvar,lto+i*12)
        if (logical,first,count,flags,reserved)!=(i,i*3,3,0,0): raise ValueError("bad HVAR logical record")
        got=[]
        for j in range(3):
            got.append(struct.unpack_from("<HHHH",hvar,cto+(i*3+j)*8))
        expected=[(76+i,300,0,0),(38+i,200,0,0),(i,100,0,0)]
        if got!=expected: raise ValueError("bad HVAR candidates")

    # Ensure dual-SCC ABI call tokens and ABI-1 page requests are in the immutable engine prefix.
    dual=templates[2][:TRACK_OFFSET]
    for token in (struct.pack("<H",DUAL_SELECT_A),struct.pack("<H",DUAL_SELECT_B),struct.pack("<H",DUAL_RESTORE)):
        if token not in dual: raise ValueError("dual-SCC ABI token missing")
    for template in templates:
        if bytes((0x6F,0x26,0x00,0xCD,0xA0,0xD8)) not in template[:TRACK_OFFSET]:
            raise ValueError("ABI-1 HL dynamic-page call sequence missing")

    return {
        "validation": {
            "strict_minor_version": "1.02",
            "header_crc": "ok",
            "index_crc": "ok",
            "resource_crcs": 4,
            "page_crcs": pc,
            "pages_reconstructed": pc,
            "hvar_logical_tracks": 38,
            "hvar_candidates": 114,
            "dual_scc_abi_tokens": ["D900", "D904", "D908"],
            "dynamic_page_abi": "A low byte and HL 16-bit",
        }
    }


def main() -> None:
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("--sccplus", type=Path, default=base / "Parodius_Da_KSP1_1.0(1).ksp")
    parser.add_argument("--normal", type=Path, default=base / "Parodius_Da_Normal_SCC_KSP1_1.0_fixed.ksp")
    parser.add_argument("--converter", type=Path, default=base / "ksp_sccplus_to_scc_fixed.py")
    parser.add_argument("--output", type=Path, default=base / "Parodius_Da_KSP1_1.02_SCC_SCCPlus_DualSCC.ksp")
    parser.add_argument("--report", type=Path, default=base / "Parodius_Da_KSP1_1.02_SCC_SCCPlus_DualSCC_report.json")
    args = parser.parse_args()
    report = build_package(args.sccplus, args.normal, args.converter, args.output, args.report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
