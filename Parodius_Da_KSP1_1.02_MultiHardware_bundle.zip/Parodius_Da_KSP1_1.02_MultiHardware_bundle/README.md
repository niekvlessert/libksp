# Parodius Da! KSP 1.02 multi-hardware package

This package contains one logical 38-track Parodius Da! collection with three
hardware implementations selected through the KSP 1.02 `HVAR` / `HVR1`
resource.

## Selection order

1. **Dual normal SCC** — quality rank 300
2. **SCC+** — quality rank 200
3. **Normal SCC** — quality rank 100 and the visible logical fallback

The KSP contains 114 physical track entries, but only the 38 logical normal-SCC
fallback entries are visible. The SCC+ and dual-SCC implementation entries are
hidden and selected automatically by an HVAR-capable player.

## Engines

- Normal SCC: PSG + SCC, using corrected dynamic waveform pairing for the
  shared channel-4/5 waveform RAM.
- SCC+: PSG + SCC+, preserving five independent HSC1 wavetable voices.
- Dual SCC: PSG + two normal SCC cartridges. HSC1 voices 1-3 use SCC A channels
  1-3 and voices 4-5 use SCC B channels 1-2, so all five supplied wavetable
  voices keep independent waveform RAM.

The dual-SCC engine uses ABI tokens `D900h`, `D904h`, and `D908h` for SCC A,
SCC B, and mapper-RAM restore. The SCC cartridges must occupy distinct slots.

## Shared music storage

The SCC+ and dual-SCC profiles use the exact same concatenated HSC1 music-data
resource and the same 43 physical RMP1 page-map payloads. Only their small Z80
engines differ. The normal-SCC profile uses a separate HSC0 resource because
its event stream contains the waveform-pairing decisions.

- Naive uncompressed music for three independent copies: 943,771 bytes
- Shared logical music data: 628,790 bytes
- Logical music bytes avoided: 314,981 bytes
- Final KSP size: 283,485 bytes

Both music resources use `KZB1` with independent forward-ZX0 blocks, allowing
RMP1 to reconstruct only the requested ranges.

## Source limitation

The supplied SCC+ HSC1 package retains five wavetable voices. It does not retain
the original sixth HuC6280 wavetable waveform. Dual SCC is therefore lossless
relative to the supplied SCC+ representation, but cannot recreate information
that is no longer present in that source KSP.

## Player requirement

This is a strict KSP 1.02 package. Playback requires a player that supports:

- minor version 2;
- multiple engines in one package;
- `HVAR` / `HVR1` selection;
- `RMP1` page reconstruction from `KZB1` page-source resources;
- dual-SCC ABI callbacks.

Older one-engine KSP 1.00/1.01 players will reject or not correctly select this
package. The package has been structurally validated, but has not been audibly
tested in openMSX or on two physical SCC cartridges.

## Rebuild

```sh
python3 build_parodius_ksp102_variants.py
```

The build is deterministic. It expects the two input KSP files and the fixed
SCC converter beside the script; all are included here.

## Validation

- Header CRC: passed
- Index CRC: passed
- Resource CRCs: 4/4 passed
- Reconstructed page CRCs: 129/129 passed
- Reconstructed pages compared with source representations: 129/129 passed
- HVAR logical records: 38
- HVAR candidates: 114
- SCC+/dual-SCC physically shared RMP1 payload pairs: 43
- Repeated build SHA-256 match: passed

Final KSP SHA-256:

```text
b77c6f66f848a5e9b47a0d31ddc80772e59719616a87696f8cfab2dc250f61ba
```
